# FE Skin Menu — One's hidden skins in the real options menu

Standalone UE4SS **Lua** mod for Fading Echo (`UE_YGRO`). It adds One's unused skins
(`Skin2`, `Skin3`, `Skin4`) as real entries in **Options > Customization**, and it can
fire the game's own skin delegates directly so you can tell, in ten seconds, whether the
game accepts those values at all.

Everything is driven from a single console command: **`skinmenu`**.

Companion to [FESkins](../ue4ss-FESkins), which paints the skins straight onto the mesh and
bypasses the menu entirely. This mod goes through the game's own option system instead.

## Installation

Copy the folder into:

```
<game>\UE_YGRO\Binaries\Win64\ue4ss\Mods\
```

so that you end up with:

```
FESkinMenu\enabled.txt
FESkinMenu\Scripts\main.lua
```

## Console

Open the in-game console with the **²** key (or use the UE4SS console window). Short status
lines are echoed to the console; **detailed output goes to the UE4SS console window**.

| Command | Effect |
|---|---|
| `skinmenu` | Current state + command reminder |
| `skinmenu dump` | Prints the skin DataAssets as they are right now (entries, labels, flags, rows) |
| `skinmenu test <0-4>` | Calls the game's own `OnSkinChanged` on One with that value |
| `skinmenu testbob <0-1>` | Calls the game's own `SetSkin` on every loaded Bob (`1` = Marcel Bob) |
| `skinmenu bobskin on\|off` | Applies Marcel Bob itself — see below |
| `skinmenu remap <a> <b>` | Makes the two menu positions drive the skins you pick — **the safe route** |
| `skinmenu revert` | Puts the original values back in the menu positions |
| `skinmenu install force` | Tries to grow the spinner to five entries — **may hard-crash** |
| `skinmenu bob` | Tries to add Bob's own row to the menu — **inert**, kept for the record |

### Settled in game (10/08/2026)

`skinmenu test 2` / `3` / `4` all change One's appearance. So `OnSkinChanged` is **generic**:
it is not limited to `"0"`/`"1"`, and a menu entry carrying `DataValue "2".."4"` is a real
button, not a dead one. That was the only thing that could have sunk the whole idea.

### Order to use it in

1. `skinmenu remap 2 3` — the two Customization positions now drive Skin2 and Skin3.
   Close the pause menu, reopen **Options > Customization**, and the spinner applies them.
   `skinmenu remap 4 0` for the next pair. `skinmenu revert` puts `0`/`1` back.
2. `skinmenu test <0-4>` if you just want to see a skin immediately, menu or no menu.
3. `skinmenu testbob 1` tells you whether Bob's `SetSkin` delegate applies Marcel Bob by
   itself, which is what a real Bob menu row would end up calling.

A remap has to land **before the options screen is created**, hence "close and reopen".
Set `BOOT_REMAP = { 2, 3 }` at the top of `Scripts/main.lua` to have it applied at startup.

Five entries at once is **not** reachable from Lua (see below) — that needs the pak.

## How it works

The five material sets ship with the game, and `BP_CoreYgroCharacter` itself carries five
populated `TMap<int32, MaterialInstance>` named `Skin0`..`Skin4` (slot → material). Only two
of them were ever reachable:

```
DA_Skin_One_Spinner.SpinnerOptions = [ DataValue "0", DataValue "1" ]
```

Moving a spinner fires `USpinnerOptionDescriptorBase::OnExecute`, a
`SpinnerDelegate(FName SpinnerValue)`. One binds `BP_CoreYgroCharacter::OnSkinChanged(FName)`
to it; Bob binds `BP_Bob_Critter::SetSkin(FName Index)`. What travels is the **DataValue
string** (`"0"`..`"4"`), not a widget index — which is why `skinmenu test` can stand in for a
menu entry that does not exist yet.

### Why `remap` and not five real entries

The intended route was the game's own API,
`USpinnerOptionDescriptor::SetSpinnerOptions(TArray<FSpinnerParameters>)`, the one
`InitResolutionData` uses. **It hard-crashes the game.** UE4SS cannot build a `TArray` of
*structs* out of a Lua table: it walks the table in `push_arrayproperty` →
`for_each_in_table` → `luaH_next` and dies on an `EXCEPTION_ACCESS_VIOLATION`. A C++ access
violation is **not catchable by `pcall`** — it is a Fatal error, the game is gone. The call
has been removed from the mod. Same warning for any UFUNCTION taking a `TArray<FStruct>`.

What is left is rewriting the `DataValue` of the two struct elements the game **already**
allocated: a plain `FName` property write, no allocation, no array growth. Hence `remap` —
two menu positions, but you choose which skins they drive. The write is verified by
**reading the array back**: a call that does not raise proves nothing.

`skinmenu install force` still tries the in-place growth for the record. It needs UE4SS to
assign a struct into an array slot *and* to grow the array past its allocation, neither of
which is established, so expect it to crash like `SetSpinnerOptions` did. Cost: one restart.

Five real entries, with proper labels, need `DA_Skin_One_Spinner` patched **on disk** in a
`_P` IoStore container. That is also the only route to a real Bob row.

### Why this is not the attempt that already failed

Two different things get confused here:

- **Adding a new descriptor row** to `DA_Skin_SubSection.OptionDescriptors` — this is what
  Bob would need, and it is **dead**. That list becomes widgets in C++ when the options
  screen is created, and nothing rebuilds it: `UOptionMenuScreen` exposes 5 UFUNCTIONs, all
  navigation, and `UOptionSubsystem` exposes only `GetOption`. Verified in game: the array
  grows, the UI does not. `skinmenu bob` keeps the attempt for the record.
- **Adding values inside an existing spinner** — this is what One needs, and the game does
  it to itself: `DA_OptionSpinner_Resolution` ships `IsSpinnerOptionsRuntimeEditable = true`
  and has its list built at runtime by `BP_OptionFunctionLibrary::InitResolutionData`. A
  spinner's values are read when the widget updates, not frozen at screen creation.

Giving Bob a real menu row needs `DA_Skin_SubSection` patched **on disk** (a `_P` IoStore
patch container), not Lua.

## Marcel Bob

In 1.0.27953 Bob's menu row (once the content patch adds it) fires but does nothing:
`BP_Bob_Critter::SetSkin` was left unfinished. This mod supplies the missing behaviour.

What Marcel Bob actually is, established by diffing 1.0.27953 against 1.0.28121 where the row
works: **a pair of materials**, not a mesh swap.

| Slot | Default | Marcel Bob |
|---|---|---|
| `M_Bob` (body) | `MM_Bob_body` → `T_BobCritter_*` | `MI_BobSkin_body` → `T_BobCritter**Skin**_*` |
| `M_bob_accessories` | `MM_Bob_Mustache` → `T_BobCritter_Accessories_*` | `MI_BobSkin_Mustache` → `T_BobCritter**Skin**_Accessories_*` |

Both must be applied together; the eyes slot is never touched. Putting the mustache material
on the *body* is what made an earlier attempt look nonsensical — it belongs on the accessories
slot.

`SKEL_Bob_Mime` is an **abandoned prototype**: nothing references it in either build, not even
as a soft reference. Bob's assets are otherwise byte-identical between the two builds — only
the Blueprint logic differs, which is why a content patch cannot supply it.

The mod applies it three ways, so it works whether or not the delegate is bound:

- a hook on `BP_Bob_Critter_C:SetSkin`, so the patched menu row drives it;
- a 2 s poll of the Bob option value, in case the delegate is never bound in this build;
- a re-assert pass for Bobs that appear after a respawn or a zone change.

`skinmenu bobskin on|off` applies or reverts it by hand.

## Caveats

- **The labels lie after a remap.** The menu keeps saying "Default" and "Hellgur One"
  whatever the positions now drive: those labels are string-table entries inside the struct
  and cannot be rewritten from Lua. Only the effect changes. Skins 2/3/4 have no name in the
  game at all — they never had a menu entry, so no key exists for them.
- **Set the skin back to Default before uninstalling.** The chosen spinner value is
  persisted. If the game saves index `3` and you then run without the mod, the stored value
  is out of range for a two-entry spinner; the clamp behaviour has not been tested.
- One's body materials have no colour parameter: a skin change swaps the whole material set
  (body / head / cape), it does not tint the existing one.
- The mod calls gameplay UFUNCTIONs and writes no statistic, so it stays out of the
  `UStatisticSubsystem` crash path.

## Verified against

Build **1.0.27953** — DataAsset contents and Blueprint signatures read from the extract;
class layout (`USpinnerOptionDescriptor`, `UOptionSubsystem`, `FSpinnerParameters`) read from
the UE4SS header dumps. Blueprint function *bodies* are bytecode and are readable in neither,
which is exactly what `skinmenu test` was for — and it came back positive on 10/08/2026.

`remap` itself has **not been tested in game yet**.
