# FE Skins — One's hidden skins, Bob's menu row, and Marcel Bob's unfinished art

Native content patch for Fading Echo **1.0.27953**, built from that build's own paks.

## Install

Copy the three files into `<game>\UE_YGRO\Content\Paks\`, then **restart the game** (containers
mount at launch):

```
UE_YGRO-Windows_P.utoc
UE_YGRO-Windows_P.ucas      (~22 MB — that is the artwork)
UE_YGRO-Windows_P.pak
```

Delete them to go back to vanilla — nothing else is touched.

## What it contains

| Package | Change |
|---|---|
| `DA_Skin_One_Spinner` | 2 → 5 entries: **Gamma One**, **Glitch One**, **Æther One** added |
| `DA_Skin_SubSection` | 1 → 2 rows: **Bob**'s spinner added |
| `SKEL_Bob_Mime` | the finished mime **geometry** from 1.0.28121 (+36 736 bytes: the beret) |
| 6 × `T_BobCritterSkin_*` | the finished 1.0.28121 **artwork** |
| 4 × `*_Skin04_*` | the finished **Æther One** artwork (see below) |

The first two were tested in game on 10/08/2026 and work.

## Why Marcel Bob was broken: the art was made after this build

Compared asset by asset against 1.0.28121, at pak level:

| Asset | 27953 vs 28121 |
|---|---|
| `SKEL_Bob_Mime` | **+36 736 bytes of geometry in 28121** — the beret is not modelled yet in 27953 |
| `T_BobCritterSkin_BCA` (body albedo) | **absent from 27953 entirely** |
| `T_BobCritterSkin_N`, `_ORM` | present, **different pixels** |
| `T_BobCritterSkin_Accessories_BCA`, `_N`, `_ORM` | present, **different pixels** |
| every `T_BobCritter_*` (ordinary Bob) | identical |
| `SKEL_Bob`, `SKEL_Bob_Skeleton`, `MM_Bob_Mustache`, `ABP_CharacterTemplate_Bob` | identical |
| `MM_Bob_body` | 134 bytes of 187 869 differ — GUIDs only, not a graph change |

So Marcel Bob simply **did not exist yet** as finished art in 27953: no beret geometry, no body
albedo, placeholder accessory maps. `MI_BobSkin_body` even pointed `BaseColor` at
`T_BobCritter_BCA`, the *ordinary* Bob's skin. The accessories material is `BLEND_Masked` with a
0.33 clip value, so an unfinished mask does not make the beret ugly — it makes it **vanish**.

None of this was reachable at runtime. The pixels and the vertices were not in the build.

## How the artwork is shipped

**The five textures that exist** keep their own names; only their bulk data is replaced. Same
`PixelFormat`, same `2048×2048`, same bulk size **to the byte**, so each original header still
describes the new pixels correctly.

**The mesh** keeps 27953's legacy header and receives 28121's export blob. That is safe here
because both packages were verified to have *identical* name maps (64 names, same order) and
*identical* import maps (13 imports, same hashes), and the same two exports at the same offsets —
so the transplanted blob resolves every reference exactly as its own build did. Only the mesh
export's `SerialSize` and `BulkDataStartOffset` were adjusted. Both builds declare the same three
material slots (`M_EyeGlass`, `M_Bob`, `M_bob_accessories`), so slot mapping is unchanged.

**The missing body albedo** rides under the name **`T_BobCritterSkin_E`**, which was free to reuse:
in 27953 it is referenced by `MI_BobSkin_body` alone, the finished material no longer uses it
(`Emissive` moved to `T_BobCritter_E`), and 1.0.28121 does not ship a texture by that name at all.
⚠️ **That name lies about its content: it holds the albedo, not the emissive.** The FESkinMenu mod
rebinds the parameters accordingly. Renaming a package inside a Zen container would have been a
far riskier edit than swapping bulk data of identical size.

## One's skins: only Æther One was unfinished

Same comparison run over One's five skins — 20 textures, four materials each:

- **16 of the 20 textures are byte-identical** between the two builds. Hellgur One, Gamma One and
  Glitch One are therefore already final in 27953: they need nothing.
- The four that differ are **all Skin04, i.e. Æther One** (`T_One_Body01_Skin04_D`,
  `T_F_Head01_Skin04_D`, `T_F_Head01_Skin04_E`, `T_F_Cape01_Skin04_D`). Same format and same bulk
  size, so they are shipped here the same way as Bob's.
- Known minor gap: `MI_MainCharaCape_cinematic_Skin4` gains an `ORM_Shard` parameter in 28121
  (pointing at `T_F_Cape01_ORM`, which already exists in 27953). That is a shading detail on the
  cape, not a colour, and adding a parameter to a material instance is a heavier edit than
  swapping bulk data — left out on purpose.

## Companion mod

The pak supplies data; Marcel Bob also needs *logic*. `BP_Bob_Critter::SetSkin` was left
unfinished in 27953, and Blueprint bytecode cannot be added by patching content. The `FESkinMenu`
UE4SS mod supplies it: mesh swap to `SKEL_Bob_Mime` on every skeletal component (including the
outline shells), dynamic material instances on all three slots, element colours, and the texture
rebinds above. Without the mod the pak still gives you the menu entries.

## Verification done

Offline but end to end. The container is rebuilt to Zen, mounted alongside the game's paks in a
simulated `Paks` directory, converted **back** to legacy, and re-decoded:

- all six textures come back **byte-identical** to the 1.0.28121 source;
- the mime mesh's export data comes back **byte-identical** to 1.0.28121's;
- the spinner reads 5 values bound to the right string-table keys; the subsection reads 2 rows
  resolving to the two spinner descriptors;
- round-tripping an unmodified package reproduces the original Zen package byte for byte, so
  retoc's reconstruction is faithful;
- `retoc verify` passes; TOC version, container-header version and mount point match the game's.
