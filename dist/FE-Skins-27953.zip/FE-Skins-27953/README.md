# FE Skins — for Fading Echo **1.0.27953**

Unlocks every character skin the game already contains but never showed, and finishes the ones
its artists had not finished yet at this build.

| | Vanilla 1.0.27953 | With this |
|---|---|---|
| Options ▸ Customization ▸ One | Default, Hellgur One | + **Gamma One**, **Glitch One**, **Æther One** |
| Options ▸ Customization | One only | + a **Bob** row (Default / **Marcel Bob**) |
| Marcel Bob | menu row absent; art unfinished | beret, black moustache, striped legs, per-element tint |
| Æther One | textures unfinished | the final artwork |

Nothing here is invented: the skins, their names and Bob's spinner all ship inside the game. What
was missing is the menu wiring, the finished artwork, and — for Bob — a piece of Blueprint logic.

## Install

Two folders, two destinations.

**1. The content patch** — copy the three files from `Paks/` into:

```
<game>\UE_YGRO\Content\Paks\
```

so you end up with `Content\Paks\UE_YGRO-Windows_P.utoc` (+ `.ucas`, `.pak`).

**2. The mod** — copy the `FESkinMenu` folder from `Mods/` into:

```
<game>\UE_YGRO\Binaries\Win64\ue4ss\Mods\
```

so you end up with `Mods\FESkinMenu\Scripts\main.lua`. This needs [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS)
installed; if you do not have it, install the pak alone — you still get every menu entry, only
Marcel Bob stays inert.

**3. Restart the game.** Containers are mounted at launch: replacing the pak while the game runs
does nothing.

## Use

Everything happens in **Options ▸ Customization**.

- **One**: pick any of the five skins, leave the section, confirm *Apply changes?*.
- **Bob**: same, on the Bob row. Bob must be **loaded in the current area** for anything to be
  visible, and the change lands within about two seconds.

One is hidden while the pause menu is open — close it entirely before judging the result.

## Uninstall

Delete the three `UE_YGRO-Windows_P.*` files and the `FESkinMenu` folder. Nothing else is touched
and no game file is overwritten: the patch is a separate container the engine mounts on top.

Set the skins back to *Default* first. The selected value is saved, and a value that no longer has
a menu entry has not been tested.

## Why a mod is needed at all

`BP_Bob_Critter::SetSkin` is unfinished in this build: it swaps Bob's mesh but never fixes his
materials. That is Blueprint bytecode, and bytecode cannot be added by patching content — hence
the small UE4SS mod, which finishes the job and re-applies it whenever the game rebuilds Bob's
materials underneath it.

The mod also carries diagnostics used while building this (`skinmenu` in the console lists them).
They are inert unless called.

## Scope

Built from **1.0.27953**'s own paks and verified against **1.0.28121**, the build where all of this
is finished. Do not install it on another version: the artwork would still load, but the menu
DataAssets are taken from 27953 and would overwrite whatever that other build ships.

`Paks/README-content-patch.md` documents exactly what each package contains and how it was made.
